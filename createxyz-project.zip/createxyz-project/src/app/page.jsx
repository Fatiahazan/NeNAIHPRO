"use client";
import React from "react";

function MainComponent() {
  // ... keep all existing code until the return statement ...

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col max-w-[480px] mx-auto relative">
      <div className="p-4 bg-white shadow">
        <div className="text-center">
          <div className="flex justify-center items-center mb-2">
            <img
              src="https://ucarecdn.com/a6ed0cfd-57c0-43c4-8f8b-1a16f145f501/-/format/auto/"
              alt="Pineapple logo with black outline drawing and orange gradient fill"
              className="w-[120px] h-[120px] object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-blue-600 font-roboto">
            NeNAIH PRO
          </h1>
          <p className="text-lg mt-1 font-roboto">
            {t("welcome")}, {formData.name}
          </p>
          <p className="text-sm text-gray-600">
            {currentDate.toLocaleDateString()}
          </p>
        </div>
      </div>

      {/* ... keep rest of the code unchanged ... */}
    </div>
  );
}

export default MainComponent;